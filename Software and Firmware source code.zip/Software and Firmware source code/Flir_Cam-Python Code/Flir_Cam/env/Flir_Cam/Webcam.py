from cv2 import cv2

#initialize camera
cam = cv2.VideoCapture(0)

#create window
cv2.namedWindow("Thermal Image Capture")

#counts how many images have been taken for naming purposes
img_counter = 0

while True:
    #read camera input
    ret, frame = cam.read()

    #if camera isnt accessible show error
    if not ret:
        print("Failed to grab frame")
        break
    #displays camera feed
    cv2.imshow("Camera Feed", frame)

    #recieves input from keyboard
    k = cv2.waitKey(1)

    #checks ascii value of inputted key

    if k%256 == 27: #if escape  key is pressed close program
        print("Escape Hit, Closing Program")
        break
    elif k%256 == 32: #if space bar is pressed picture is taken
        #names image
        img_name = "thermal_image{}.jpg".format(img_counter)
        #saves image
        cv2.imwrite(img_name,frame)
        print("Screnshot taken")
        img_counter += 1
#closes camera and end program
cam.release()
cv2.destroyAllWindows()