This code allows the user to capture and save thermal images from the FLIR 3.5 Thermal Camera
when it is connected via USB using a mouse and keyboard.

Button commands:

space bar -> Captures and saves image
escape key -> Closes program

****************************************
Libraries Used:
Opencv (cv2) - pip install opencv-contrib-python

System Packages to interpret images, video, etc:
 
CMake - build-essential cmake pkg-config
libjpeg-dev libtiff5-dev libjasper-dev libpng-dev
libavcodec-dev libavformat-dev libswscale-dev libv4l-dev
libxvidcore-dev libx264-dev
libfontconfig1-dev libcairo2-dev
libgdk-pixbuf2.0-dev libpango1.0-dev
libgtk2.0-dev libgtk-3-dev
libatlas-base-dev gfortran
libhdf5-dev libhdf5-serial-dev libhdf5-103
libqt5gui5 libqt5webkit5 libqt5test5 python3-pyqt5

******************************************************

The following guides were used:

Installing Libraries:

https://singleboardbytes.com/647/install-opencv-raspberry-pi-4.htm
https://www.youtube.com/watch?v=QzVYnG-WaM4&t=2

Writing Code:
https://www.geeksforgeeks.org/how-to-capture-a-image-from-webcam-in-python/?ref=gcse
https://www.geeksforgeeks.org/python-opencv-waitkey-function/?ref=gcse
https://www.geeksforgeeks.org/python-opencv-capture-video-from-camera/?ref=gcse