This code is used to receive input from a playstation controller and send those commands to an Adafruit PCA9685 Servomotor Controller.

Signal Path:
Playstation Controller -> Raspberry Pi/ Jeton Nano -> Adafruit PCA9685 Servomotor Controller

***********************
Imported Libraries:
pygame
math
time
board
busio
adafruit_pca9685.mpy
adafruit_bus_device
adafruit_register
adafruit_motor
adafruit_servokit (ServoKit)
**********************

Guide and instructions on installation here:

https://learn.adafruit.com/16-channel-pwm-servo-driver/using-the-adafruit-library
https://github.com/adafruit/Adafruit-PWM-Servo-Driver-Library
https://github.com/adafruit/Adafruit_CircuitPython_PCA9685