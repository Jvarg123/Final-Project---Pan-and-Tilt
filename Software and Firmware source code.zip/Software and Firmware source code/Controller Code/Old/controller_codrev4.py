#control angle with controller
#angle stays within range of 0-180
#send angle to servos
import pygame
import math
import time
from adafruit_servokit import ServoKit
import board
import busio
import adafruit_pca9685
pygame.init()


#initialize I2C bus
SDA = board.SDA
SCL = board.SCL
i2c = busio.I2C(SCL,SDA)

#initialize motor driver
pca = adafruit_pca9685.PCA9685(i2c)

#keeps angle of rotation within limits of 0-180
def rail(angle):
    minn = 0
    maxn = 180
    if angle > maxn: #if angle is over max return max
        return maxn
    elif angle < minn: #if angle is under min return min
        return minn
    else:
        return angle #if angle is within bounds return
    
#clock = pygame.time.Clock()
speed = 5
joystick = None
tilt_angle = 0
pan_angle = 0
buffer = 0.1

done = False
while not done:
    kit = ServoKit(channels=16, i2c = i2c) #declaring servos
    pan_servo = kit.servo[0]
    tilt_servo = kit.servo[1]       
    pan_servo.angle = pan_angle #setting servo angles
    tilt_servo.angle = tilt_angle
    
    #clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        elif event.type == pygame.KEYDOWN:
            if event.key==pygame.K_RETURN:
                done = True

    #checks if controller has been initialized
    if joystick:
        
        #get angle of analog stick
        axis_x, axis_y = (joystick.get_axis(0), joystick.get_axis(1))
        
        #if motion is detected, with a small buffer to avoid noise, adjust angle
        if abs(axis_x) > buffer:
            pan_angle = rail(pan_angle + (speed * axis_x))
            
        if abs(axis_y) > buffer:
            tilt_angle = rail(tilt_angle + (speed * axis_y))
           
        pan_angle = math.ceil(pan_angle) #round angle to nearest whole number
        tilt_angle = math.ceil(tilt_angle)
        print("pan = ", pan_angle)
        print("tilt = ",tilt_angle)
        
    else: #initialize controller if it hasn't been already
        if pygame.joystick.get_count() > 0:
            joystick = pygame.joystick.Joystick(0)
            joystick.init()
            print("joystick initialized")