#control angle with controller
#angle stays within range of 0-180
import pygame
import math
pygame.init()

def rail(angle):
    minn = 0
    maxn = 180
    if angle > maxn: #keeps angle of rotation within limits of 0-180
        return maxn
    elif angle < minn:
        return minn
    else:
        return angle
    
clock = pygame.time.Clock()
speed = 5
joystick = None
tilt_angle = 0
pan_angle = 0

done = False
while not done:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        elif event.type == pygame.KEYDOWN:
            if event.key==pygame.K_RETURN:
                done = True

    if joystick:
        axis_x, axis_y = (joystick.get_axis(0), joystick.get_axis(1))
        if abs(axis_x) > 0.1:
            pan_angle = rail(pan_angle + (speed * axis_x))
            

        if abs(axis_y) > 0.1:
            tilt_angle = rail(tilt_angle + (speed * axis_y))
           
        pan_angle = math.ceil(pan_angle)
        tilt_angle = math.ceil(tilt_angle)
        print("pan = ", pan_angle)
        print("tilt = ",tilt_angle)
        
    else:
        if pygame.joystick.get_count() > 0:
            joystick = pygame.joystick.Joystick(0)
            joystick.init()
            print("joystick initialized")