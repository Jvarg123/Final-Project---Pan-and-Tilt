import spidev
import time


spi_bus = 0
spi_device = 0

spi = spidev.SpiDev()
spi.open(spi_bus,spi_device)
spi.mode = 0b01
spi.max_speed_hz = 5000000


while True:
    send_byte = 0x01
    spi.xfer([send_byte])
    print(send_byte)
    time.sleep(0.1)
   
print("end")   
    