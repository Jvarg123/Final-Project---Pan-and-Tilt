import spidev
import struct
import time

# Initialize SPI interface
spi = spidev.SpiDev()
spi.open(0, 0)

# Set SPI mode and clock frequency
spi.max_speed_hz = 1000000
spi.mode = 0b00

# Continuously send data
while True:
    # Convert integer to bytes 
    value = 180  # Test Value
    data = struct.pack('>i', value)

    # Send data over SPI and print sent value
    response = spi.xfer(list(data))
    print('Sent value:', value)

    # Wait before sending the next value
    time.sleep(0.1)
