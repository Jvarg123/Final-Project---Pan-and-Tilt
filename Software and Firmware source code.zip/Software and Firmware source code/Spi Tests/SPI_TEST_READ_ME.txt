This is code that we are using to test the Raspberry PI's capabilities of sending SPI data to the micro controller (raspberry pi Pico)

We are so far unsuccessful 

***********************************
Imported Libraries:
time
spidev