This is code that we are using to test the Raspberry PI's capabilities of sending SPI data to the micro controller (raspberry pi Pico)

The code runs fine but the Pico is unable to recieve data. We suspect there is an something causing the chip-select pin to malfunction


 Raspberry Pi to Pico Connections                    
                                
   GP10 MOSI   -------  Pico GP19     
   GP9  MISO   -------  Pico GP16     
   GP11 SCLK   -------  Pico GP18     
   GP8  CE0    -------  Pico GP17    
   	GND    -------  GND           
                                 


***********************************
Imported Libraries:
time
spidev
struct