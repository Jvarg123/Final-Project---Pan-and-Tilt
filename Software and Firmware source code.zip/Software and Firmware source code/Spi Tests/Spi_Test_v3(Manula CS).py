import spidev
import struct
import time
import RPi.GPIO as GPIO

# Initialize SPI interface
spi = spidev.SpiDev()
spi.open(0, 0)

# Set SPI mode and clock frequency
spi.max_speed_hz = 1000000
spi.mode = 0b00
GPIO.setmode(GPIO.BCM)
CS_PIN = 8
GPIO.setup(CS_PIN,GPIO.OUT)
# Continuously send data
while True:
    # Convert integer to bytes 
    value = 180  # Test Value
    data = struct.pack('>i', value)

    # Send data over SPI and print sent value
    #CS PIN is toggled manually
    GPIO.output(CS_PIN,GPIO.LOW)
    response = spi.xfer(list(data))
    print('Sent value:', value)
    GPIO.output(CS_PIN,GPIO.HIGH)

    # Wait before sending the next value
    time.sleep(0.1)
