This is code where we are trying to get the Raspberry Pi Pico to read SPI commands being sent by the Raspberry Pi or Jetson Nano.

So far we are unsuccessful 