There are two programs here.

One which rotates a servomotor continusously and another which attempts to receive SPI data

There seems to be a problem with the SPI functionality on the pico. The code runs fine but nothing is being recieved. It seems that the Chip-select line is never being activated.

To setup the raspberry pi pico to work with circuitpython follow the guide here:
https://learn.adafruit.com/getting-started-with-raspberry-pi-pico-circuitpython/circuitpython

The lib folder contains the libaries necessary to run the code properly

This code sends commands to the motor controller in a loop
******************************
Imported Libaries:
time
board
busio
struct
adafruit_pca9685.mpy
adafruit_bus_device
adafruit_register
adafruit_motor
adafruit_servokit (ServoKit)
******************************

Guide and instructions on installation here:

https://learn.adafruit.com/16-channel-pwm-servo-driver/using-the-adafruit-library
https://github.com/adafruit/Adafruit-PWM-Servo-Driver-Library
https://github.com/adafruit/Adafruit_CircuitPython_PCA9685