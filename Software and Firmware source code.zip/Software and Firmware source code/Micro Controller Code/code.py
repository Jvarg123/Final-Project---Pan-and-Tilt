# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT

#control motors by manually inputting angle of rotation
import time
import sys
from adafruit_servokit import ServoKit
import board
import busio
import adafruit_pca9685


#initialize I2C bus
sda = board.SDA
scl = board.SCL
i2c = busio.I2C(scl,sda)

#initialize motor driver
pca = adafruit_pca9685.PCA9685(i2c)


# Set channels to the number of servo channels on your kit.
# 8 for FeatherWing, 16 for Shield/HAT/Bonnet.
while True:    
    kit = ServoKit(channels=16, i2c = i2c)
    kit.servo[0].angle = 0
    time.sleep(1)
    kit.servo[0].angle = 180
    time.sleep(1)
    kit.servo[0].angle = 0
    time.sleep(1)
    kit.servo[0].angle = 100
    time.sleep(1)
    kit.servo[0].angle = 0
    time.sleep(1)
    kit.servo[0].angle = 180
    time.sleep(1)