import board
import busio
import digitalio
import struct

SCK = board.GP18
MOSI = board.GP19
MISO = board.GP16

# Initialize SPI bus
spi = busio.SPI(SCK, MOSI, MISO)

# Initialize chip select pin
cs = digitalio.DigitalInOut(board.GP17)
cs.direction = digitalio.Direction.OUTPUT
cs.value = True

while True:
    # Try to lock the SPI bus
    while not spi.try_lock():
        pass
    
    # Set SPI mode and clock frequency
    spi.configure(baudrate=1000000, phase=0, polarity=0)
    
    # wait until data is being sent
    while cs.value == True:
        pass

    # Receive 4 bytes of data over SPI
    data = bytearray(4)
    spi.readinto(data)

    # Convert received data to integer
    value = struct.unpack('>i', data[0])#[0]

    # Set chip select back to high
    cs.value = True

    # Unlock the SPI bus
    spi.unlock()

    # Print received value
    print('Received value:', value)
