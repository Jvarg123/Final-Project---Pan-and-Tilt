import board
import busio
from adafruit_bus_device.spi_device import SPIDevice
import digitalio
import time

SCK = board.GP18
MISO = board.GP16
MOSI = board.GP19
cs = digitalio.DigitalInOut(board.GP17)
cs.direction = digitalio.Direction.OUTPUT
cs.value = True

spi_bus = busio.SPI(SCK,MOSI,MISO)
device = SPIDevice(spi_bus,cs,baudrate=5000000, polarity=0, phase=0)


while not spi_bus.try_lock():
    pass


while True:
    result = bytearray(1)
    cs.value = False
    spi_bus.readinto(result)
    print(result)
    cs.value = True
    time.sleep(0.5)
   



