import board
import busio
import struct
import digitalIO

spi = busio.SPI(board.GP2, board.GP3, board.GP4)
cs = digitalIO(board.GP5)  # Use GP5 as CS pin
cs.direction = Direction.OUTPUT
cs.value = True  # Deselect device

# Configure SPI bus for receiving data
spi.configure(baudrate=1000000, phase=0, polarity=0, bits=8)

while True:
    # Receive data over SPI and convert to integer
    cs.value = False  # Select device
    data = bytearray(4)  # Receive 4 bytes of data
    spi.readinto(data)
    cs.value = True  # Deselect device

    value = struct.unpack(">i", data)[0]  # Convert data to integer

    print("Received value:", value)
