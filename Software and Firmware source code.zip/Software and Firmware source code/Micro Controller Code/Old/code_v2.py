# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT

"""Simple test for a standard servo on channel 0 and a continuous rotation servo on channel 1."""
import time
from adafruit_servokit import ServoKit
import board
import busio
import adafruit_pca9685
import digitalio
from adafruit_bus_device.spi_device import SPIDevice



SDA = board.GP0
SCL = board.GP1
SCK = board.GP18
TX = board.GP16
RX = board.GP19
CS = digitalio.DigitalInOut(board.GP17)
CS.direction = digitalio.Direction.OUTPUT
CS.value = True
test = True
#initialize I2C bus
#i2c = busio.I2C(SCL,SDA)

#initialize SPI bus
spi = busio.SPI(SCK,RX,TX)
while True:
    print("!")
    while not spi.try_lock():
        pass
    spi.configure(baudrate = 115200, phase = 0, polarity = 0)
    CS.value = False
    result = bytearray(4)
    spi.readinto(result)
    CS.value = True
    print(result)
#device = SPIDevice(spi, CS, baudrate = 115200, polarity=0,phase=0)


#initialize motor driver
#pca = adafruit_pca9685.PCA9685(i2c)


# Set channels to the number of servo channels on your kit.
# 8 for FeatherWing, 16 for Shield/HAT/Bonnet.
#while True:    
    #kit = ServoKit(channels=16, i2c = i2c)
    #kit.servo[0].angle = 0
    #time.sleep(1)
    #kit.servo[0].angle = 10
    #time.sleep(1)
    #kit.servo[0].angle = 50
    #time.sleep(1)
    #kit.servo[0].angle = 0
    #time.sleep(1)
    #kit.servo[0].angle = 180
    #time.sleep(1)
    #kit.servo[0].angle = 20
    #time.sleep(1)
