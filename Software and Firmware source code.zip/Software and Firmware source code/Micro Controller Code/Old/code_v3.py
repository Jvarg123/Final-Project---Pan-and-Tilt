# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT
#use different spi libraries

import time
from adafruit_servokit import ServoKit
import board
import busio
import adafruit_pca9685
import digitalio
import spidev
from adafruit_bus_device.spi_device import SPIDevice

SDA = board.GP0
SCL = board.GP1
SCK = board.GP18
MISO = board.GP16
MOSI = board.GP19
cs = digitalio.DigitalInOut(board.GP17)
cs.direction = digitalio.Direction.OUTPUT
while True:
    with busio.SPI(SCK,MOSI,MISO) as spi_bus:
        
        device = SPIDevice(spi_bus,cs)
        result = bytearray(1)
        
        with device as spi:
            cs.value = False
            spi.readinto(result)
            cs.value = True
            print(result)
            time.sleep(0.1)

#initialize I2C bus
#i2c = busio.I2C(SCL,SDA)

#initialize motor driver
#pca = adafruit_pca9685.PCA9685(i2c)


# Set channels to the number of servo channels on your kit.
# 8 for FeatherWing, 16 for Shield/HAT/Bonnet.
#while True:    
    #kit = ServoKit(channels=16, i2c = i2c)
    #kit.servo[0].angle = 0
    #time.sleep(1)
    #kit.servo[0].angle = 10
    #time.sleep(1)
    #kit.servo[0].angle = 50
    #time.sleep(1)
    #kit.servo[0].angle = 0
    #time.sleep(1)
    #kit.servo[0].angle = 180
    #time.sleep(1)
    #kit.servo[0].angle = 20
    #time.sleep(1)
